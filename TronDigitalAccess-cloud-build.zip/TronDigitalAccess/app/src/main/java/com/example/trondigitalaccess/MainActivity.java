package com.example.trondigitalaccess;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    int cyan = Color.rgb(0, 220, 255);
    LinearLayout root;
    TextView status, button;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 24, 28, 24);
        root.setBackgroundColor(Color.rgb(3, 8, 18));
        TextView title = text("TRON", 34, cyan);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        TextView sub = text("DIGITAL ACCESS", 15, Color.WHITE);
        sub.setLetterSpacing(.25f);
        root.addView(sub);
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, 65));
        TextView ring = text("◎", 120, cyan);
        ring.setGravity(Gravity.CENTER);
        root.addView(ring, new LinearLayout.LayoutParams(-1, 180));
        status = text("SYSTEM STANDBY", 16, cyan);
        root.addView(status);
        View gap2 = new View(this);
        root.addView(gap2, new LinearLayout.LayoutParams(1, 45));
        button = text("SCAN ACCESS", 18, Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setPadding(28, 18, 28, 18);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(0, 35, 52));
        bg.setCornerRadius(18);
        bg.setStroke(2, cyan);
        button.setBackground(bg);
        root.addView(button, new LinearLayout.LayoutParams(-1, -2));
        button.setOnClickListener(v -> {
            button.setEnabled(false);
            status.setText("SCANNING...");
            button.postDelayed(() -> {
                status.setText("ACCESS GRANTED");
                button.setText("DOOR UNLOCKED");
                button.setEnabled(true);
                button.setOnClickListener(w -> {
                    status.setText("SYSTEM STANDBY");
                    button.setText("SCAN ACCESS");
                    button.setOnClickListener(x -> scan());
                });
            }, 1800);
        });
        setContentView(root);
    }
    void scan() {
        button.setEnabled(false);
        status.setText("SCANNING...");
        button.postDelayed(() -> {
            status.setText("ACCESS GRANTED");
            button.setText("DOOR UNLOCKED");
            button.setEnabled(true);
        }, 1800);
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(8, 8, 8, 8);
        return t;
    }
}
